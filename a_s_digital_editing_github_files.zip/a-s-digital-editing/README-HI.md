# A & S Digital Editing — GitHub Pages

यह Canva-जैसे डिजाइन एडिटर का शुरुआती वर्ज़न है। यह एक static website है और GitHub Pages पर चल सकता है।

## अभी उपलब्ध सुविधाएँ
- हिंदी/English UI toggle
- टेक्स्ट जोड़ना और बदलना
- रंगीन rectangle और circle जोड़ना
- अपनी फोटो अपलोड करना
- कैनवास पर आइटम को drag करके स्थान बदलना
- आकार, रंग, टेक्स्ट और position बदलना
- स्कूल, YouTube और त्योहार के शुरुआती templates
- Undo/Redo
- PNG डाउनलोड

## मोबाइल से GitHub Pages पर लगाएँ
1. GitHub में लॉगिन करें और `New repository` दबाएँ।
2. Repository का नाम `my-design-studio` रखें और `Public` चुनें।
3. `Create repository` दबाएँ।
4. `Add file` → `Create new file` चुनें।
5. फ़ाइल का नाम ठीक `index.html` लिखें।
6. इस पैकेज में मौजूद `index.html` का पूरा कोड कॉपी करके पेस्ट करें।
7. नीचे `Commit changes` दबाएँ।
8. Repository में `Settings` → `Pages` खोलें।
9. `Build and deployment` में `Deploy from a branch` चुनें।
10. Branch में `main` और folder में `/(root)` चुनकर `Save` दबाएँ।
11. 1–3 मिनट बाद Pages पेज पर दिखने वाला वेबसाइट लिंक खोलें। लिंक आम तौर पर `https://YOUR-USERNAME.github.io/my-design-studio/` जैसा होगा।

## अपनी ब्रांडिंग बदलना
`index.html` में `A & S Digital Editing` खोजकर अपनी पसंद का नाम लिखें। शीर्षक में `A & S Digital Editing` भी बदल सकते हैं। लोगो के छोटे रंगीन बॉक्स में अभी `A&S` है; चाहें तो इसे अपने ब्रांड के शुरुआती अक्षर से बदलें।

## महत्वपूर्ण सीमाएँ
यह Canva का पूरा विकल्प नहीं है। अभी login/cloud saving, team collaboration, video timeline, PDF export, AI image generation और background remover शामिल नहीं हैं। इन सुविधाओं के लिए आगे अलग backend/API या सेवाएँ जोड़नी होंगी। API keys को कभी भी public `index.html` में न रखें।
